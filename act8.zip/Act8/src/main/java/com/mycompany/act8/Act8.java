package com.mycompany.act8;

import java.util.ArrayList;
import java.util.Collections;

// Clase que representa una carta de poker
class Card {
    private String palo;
    private String color;
    private String valor;

    public Card(String palo, String color, String valor) {
        this.palo = palo;
        this.color = color;
        this.valor = valor;
    }

    public String getPalo() {
        return palo;
    }

    public String getColor() {
        return color;
    }

    public String getValor() {
        return valor;
    }

    @Override
    public String toString() {
        return palo + "," + color + "," + valor;
    }
}

// Clase que representa el conjunto de cartas de poker
class Deck {
    private ArrayList<Card> cards;

    public Deck() {
        cards = new ArrayList<>();
        initializeDeck();
    }

    // Inicializa el deck con las 52 cartas de poker
    private void initializeDeck() {
        String[] palos = {"tréboles", "corazones", "picas", "diamantes"};
        String[] colores = {"negro", "rojo"};
        String[] valores = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "A", "J", "Q", "K"};

        for (String palo : palos) {
            for (String color : colores) {
                for (String valor : valores) {
                    cards.add(new Card(palo, color, valor));
                }
            }
        }
    }

    // Mezcla el deck
    public void shuffle() {
        Collections.shuffle(cards);
        System.out.println("Se mezcló el Deck.");
    }

    // Muestra y remueve la primera carta del deck
    public void head() {
        Card card = cards.remove(0);
        System.out.println(card);
        System.out.println("Quedan " + cards.size() + " cartas en el deck");
    }

    // Selecciona y remueve una carta al azar del deck
    public void pick() {
        int randomIndex = (int) (Math.random() * cards.size());
        Card card = cards.remove(randomIndex);
        System.out.println(card);
        System.out.println("Quedan " + cards.size() + " cartas en el deck");
    }

    // Regresa un arreglo de cinco cartas del deck
    public void hand() {
        for (int i = 0; i < 5; i++) {
            Card card = cards.remove(0);
            System.out.println(card);
        }
        System.out.println("Quedan " + cards.size() + " cartas en el deck");
    }
}

public class Act8 {
    public static void main(String[] args) {
        Deck deck = new Deck();

        // Prueba de los métodos
        deck.shuffle();
        System.out.println();
        deck.head();
        System.out.println();
        deck.pick();
        System.out.println();
        deck.hand();
    }
}