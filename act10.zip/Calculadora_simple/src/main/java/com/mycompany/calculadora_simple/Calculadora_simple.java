package com.mycompany.calculadora_simple;


import java.util.Scanner;
public class Calculadora_simple {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

   
        System.out.print("primer atributo (X)= ");
        int x = scanner.nextInt();
        System.out.print("segundo atributo (Y)= ");
        int y = scanner.nextInt();

        
        calc calc = new calc(x, y);

        
        calc.imprimir();

        
        
    }
}

class calc {
    int x;
    int y;

    
    public calc(int x, int y) {
        this.x = x;
        this.y = y;
    }

    
    public void imprimir() {
        System.out.println("X = " + x);
        System.out.println("Y = " + y);
        System.out.println("Suma: " + (x + y));
        System.out.println("Resta: " + (x - y));
        System.out.println("Multiplicación: " + (x * y));
        
        if (y != 0) {
            System.out.println("División: " + ((double) x / y));
            System.out.println("Módulo: " + (x % y));
        } else {
            System.out.println("No es posible dicidir entre 0.");
        }
    }
}


